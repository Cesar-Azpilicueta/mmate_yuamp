package com.flash21.yuamp_android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    private WebView wv;

    private String INDEX_PAGE;

    private boolean mFlag = false;

    public static CookieManager cookieManager = null;

    private String tk = "";
    private String tk_temp = "";
    InsertToken it = null;

    String marketVersion, verSion;
    AlertDialog.Builder mDialog;

    private static final int INPUT_FILE_REQUEST_CODE = 1;
    private static final String TYPE_IMAGE = "*/*";

    private ValueCallback<Uri> mUploadMessage;
    private ValueCallback<Uri[]> mFilePathCallback;
    private String mCameraPhotoPath;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CookieSyncManager.createInstance(this);
        cookieManager = CookieManager.getInstance();
        CookieSyncManager.getInstance().startSync();

        Intent intent = getIntent();
        INDEX_PAGE = intent.getStringExtra("moveUrl");
        //Log.e("moveUrl", INDEX_PAGE);

        wv = (WebView) findViewById(R.id.webView);

        WebViewInterface wi = new WebViewInterface(MainActivity.this, wv);
        wv.addJavascriptInterface(wi, "android");

        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setAllowUniversalAccessFromFileURLs(true);
        wv.getSettings().setBuiltInZoomControls(true);
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            // Hide the zoom controls for HONEYCOMB+
            wv.getSettings().setDisplayZoomControls(false);
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
            wv.getSettings().setTextZoom(100);
        }

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
//                return super.onJsAlert(view, url, message, result);
                new AlertDialog.Builder(view.getContext())
//                    .setTitle("메세지")d
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        result.confirm();
                                    }
                                })
                        .setCancelable(true)
                        .create()
                        .show();

                return true;
            }


            // For Android Version < 3.0
            public void openFileChooser(ValueCallback<Uri> uploadMsg) {
                //System.out.println("WebViewActivity OS Version : " + Build.VERSION.SDK_INT + "\t openFC(VCU), n=1");
                mUploadMessage = uploadMsg;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(TYPE_IMAGE);
                startActivityForResult(intent, INPUT_FILE_REQUEST_CODE);
            }

            // For 3.0 <= Android Version < 4.1
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
                //System.out.println("WebViewActivity 3<A<4.1, OS Version : " + Build.VERSION.SDK_INT + "\t openFC(VCU,aT), n=2");
                openFileChooser(uploadMsg, acceptType, "");
            }

            // For 4.1 <= Android Version < 5.0
            public void openFileChooser(ValueCallback<Uri> uploadFile, String acceptType, String capture) {
                Log.d(getClass().getName(), "openFileChooser : "+acceptType+"/"+capture);
                mUploadMessage = uploadFile;
                imageChooser();
            }

            // For Android Version 5.0+
            // Ref: https://github.com/GoogleChrome/chromium-webview-samples/blob/master/input-file-example/app/src/main/java/inputfilesample/android/chrome/google/com/inputfilesample/MainFragment.java
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                System.out.println("WebViewActivity A>5, OS Version : " + Build.VERSION.SDK_INT + "\t onSFC(WV,VCUB,FCP), n=3");
                if (mFilePathCallback != null) {
                    mFilePathCallback.onReceiveValue(null);
                }
                mFilePathCallback = filePathCallback;

                imageChooser();
                return true;
            }

            private void imageChooser() {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    // Create the File where the photo should go
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                        takePictureIntent.putExtra("PhotoPath", mCameraPhotoPath);
                    } catch (IOException ex) {
                        // Error occurred while creating the File
                        Log.e(getClass().getName(), "Unable to create Image File", ex);
                    }

                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                        mCameraPhotoPath = "file:"+photoFile.getAbsolutePath();
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(photoFile));
                    } else {
                        takePictureIntent = null;
                    }
                }

                Intent contentSelectionIntent = new Intent(Intent.ACTION_GET_CONTENT);
                contentSelectionIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentSelectionIntent.setType(TYPE_IMAGE);

                Intent[] intentArray;
                if(takePictureIntent != null) {
                    intentArray = new Intent[]{takePictureIntent};
                } else {
                    intentArray = new Intent[0];
                }

                Intent chooserIntent = new Intent(Intent.ACTION_CHOOSER);
                chooserIntent.putExtra(Intent.EXTRA_INTENT, contentSelectionIntent);
                chooserIntent.putExtra(Intent.EXTRA_TITLE, "Image Chooser");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray);

                startActivityForResult(chooserIntent, INPUT_FILE_REQUEST_CODE);
            }


            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(view.getContext())
                        .setTitle("알림")
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                        result.confirm();
                                    }
                                })
                        .setNegativeButton(android.R.string.cancel,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                        result.cancel();
                                    }
                                }).setCancelable(false).create().show();
                return true;
            }
        });

        wv.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimeType,
                                        long contentLength) {

                try{
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));

                    CookieManager cookieManager = CookieManager.getInstance();
                    String cookie = cookieManager.getCookie(url);
                    request.addRequestHeader("Cookie", cookie);

                    request.setMimeType(mimeType);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.setDescription("Downloading file");

                    contentDisposition = URLDecoder.decode(contentDisposition, "UTF-8");

                    String fileName = contentDisposition.replaceAll("inline; filename=", "").replaceAll("inline;filename=", "");

                    if(contentDisposition.indexOf("inline; filename=") > -1 || contentDisposition.indexOf("inline;filename=") > -1){ //content-desposition 이 inline; filename= 로 되어있을경우
                        request.setTitle(fileName);
                    }else{ //content-desposition 이 attachment; filename= 로 되어있을경우
                        request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType));
                    }

                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                    if(contentDisposition.indexOf("inline; filename=") > -1 || contentDisposition.indexOf("inline;filename=") > -1){
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
                    }else{
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType));
                    }

                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(getApplicationContext(), "Downloading File", Toast.LENGTH_LONG).show();
                }catch(Exception e){

                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        // Should we show an explanation?
                        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                            Toast.makeText(getBaseContext(), "첨부파일 다운로드를 위해\n동의가 필요합니다.\n(동의를 하였으나 작동되지 않을 경우 '설정>앱>"+getResources().getString(R.string.app_name)+">권한 의 저장권한을 on 해주세요.')", Toast.LENGTH_LONG).show();
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                    1000);
                        } else {
                            Toast.makeText(getBaseContext(), "첨부파일 다운로드를 위해\n동의가 필요합니다.\n(동의를 하였으나 작동되지 않을 경우 '설정>앱>"+getResources().getString(R.string.app_name)+">권한 의 저장권한을 on 해주세요.')", Toast.LENGTH_LONG).show();
                            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                    1000);
                        }
                    }
                }
            }
        });

        //wv.setWebViewClient(new WebViewClient());
        wv.setWebViewClient(new SiteWebViewClient());
        String userAgent = wv.getSettings().getUserAgentString();
        wv.getSettings().setUserAgentString(userAgent + " app_flash21_mmate_android");
        //wv.addJavascriptInterface(new JavaScriptInterface(this), "Apps");
        wv.loadUrl(INDEX_PAGE);
        //앱버전 체크
        mDialog = new AlertDialog.Builder(this);
        new getMarketVersion().execute();
    }

    @Override
    protected void onResume() {
        super.onResume();

        tokenRefresh();
    }

    // 최초실행시 토큰값을 못가져오는 기기가 있어서 처리
    private void tokenRefresh() {
        tk = FirebaseInstanceId.getInstance().getToken(); //토큰값 받기
        //Log.e("tk", tk);
        //Log.e("tk_temp", tk_temp);

        if(tk != null && !tk.equals("") &&!tk.equals(tk_temp)){
            tk_temp = tk;

            if(it == null) it = new InsertToken();
            it.execute(new String[]{PageInfo.INSERT_PUSH_DATA_PAGE});
        }
    }

    private class SiteWebViewClient extends WebViewClient {

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            final String webUrl = url;

            if (webUrl.startsWith("tel:")) {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("알림")
                        .setMessage("통화를 하시겠습니까?")
                        .setPositiveButton(android.R.string.ok,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                        Intent call_phone = new Intent(Intent.ACTION_VIEW,  Uri.parse(webUrl));

                                        startActivity(call_phone);
                                    }
                                })

                        .setNegativeButton(android.R.string.cancel, null)
                        .setCancelable(false).create().show();
                return true;

            }else if (webUrl.startsWith("mailto:")) {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("알림")
                        .setMessage("이메일을 보내시겠습니까?")
                        .setPositiveButton(android.R.string.ok,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                        String email = webUrl.replace("mailto:", "");
                                        final Intent intent = new Intent(
                                                Intent.ACTION_SEND);
                                        intent.setType("plain/text");
                                        intent.putExtra(Intent.EXTRA_EMAIL,
                                                new String[] { email });
                                        intent.putExtra(Intent.EXTRA_SUBJECT, "제목");
                                        intent.putExtra(Intent.EXTRA_TEXT, "내용");
                                        startActivity(Intent.createChooser(intent, "이메일 전송"));
                                    }
                                })

                        .setNegativeButton(android.R.string.cancel, null)
                        .setCancelable(false).create().show();
                return true;
            }else if (webUrl.startsWith("sms:")) {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("알림")
                        .setMessage("문자발송 하시겠습니까?")
                        .setPositiveButton(android.R.string.ok,
                                new AlertDialog.OnClickListener() {
                                    public void onClick(
                                            DialogInterface dialog,
                                            int which) {
                                        Intent call_phone = new Intent(Intent.ACTION_SENDTO,  Uri.parse(webUrl));

                                        startActivity(call_phone);
                                    }
                                })

                        .setNegativeButton(android.R.string.cancel,

                                null)
                        .setCancelable(false).create().show();
                return true;
            }else if (webUrl.contains("views/user/hongbo_board/img_view.html")) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
                return true;
            }else{
                view.loadUrl(url);
                return true;
            }
        }

        public void onPageFinished(WebView view, String url) {
            //앱종료 플래그
            mFlag = false;
        }
    }

    //기기 back버튼
    @Override
    public void onBackPressed() {
        //Log.e("nowUrl", wv.getOriginalUrl());
        if (wv.getOriginalUrl().equalsIgnoreCase(PageInfo.INDEX_PAGE)) {
            if(!mFlag){
                Toast.makeText(this, "'뒤로'버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT).show();
                mFlag = true;
            }else{
                finish();
            }
        }else if(wv.canGoBack()){
            wv.goBack();
        }else if(wv.getOriginalUrl().equalsIgnoreCase(PageInfo.FAIL_PAGE)){
            //  Log.i("aaaaaa", "실패페이지");
            finish();
        }else if(wv.getOriginalUrl().equalsIgnoreCase(PageInfo.INDEX_PAGE)){
            wv.loadUrl(PageInfo.INDEX_PAGE);
        }else{
            super.onBackPressed();
        }
    }

    // TOKEN 입력 //
    @SuppressWarnings("deprecation")
    private class InsertToken extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... urls) {
            String url = urls[0];

            PackageInfo info = null;
            try {
                info = getPackageManager().getPackageInfo(getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

            if(getDeviceInfo()[0] == null) return false;

            try {
                System.out.println("telManager");
                ArrayList<NameValuePair> pairs = new ArrayList<NameValuePair>();
                pairs.add(new BasicNameValuePair("key_num", tk));
                pairs.add(new BasicNameValuePair("j_cellNo", getDeviceInfo()[0]));
                /*pairs.add(new BasicNameValuePair("j_cellNo", "01043305737"));*/
                pairs.add(new BasicNameValuePair("device", getDeviceInfo()[1]));
                pairs.add(new BasicNameValuePair("version", getDeviceInfo()[2]));
                pairs.add(new BasicNameValuePair("type", "android"));
                pairs.add(new BasicNameValuePair("j_siteKey", "ST0043"));
                pairs.add(new BasicNameValuePair("j_division", "MOBILE"));
                pairs.add(new BasicNameValuePair("app_version", info.versionCode + ""));

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(url);
                post.setEntity(new UrlEncodedFormEntity(pairs, "utf-8"));

                HttpResponse response = client.execute(post);

                HttpEntity ent = response.getEntity();
                //Log.e("Response Value", EntityUtils.toString(ent));
                InputStream is = null;
                String result = "";
                is = ent.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);	// 인코딩 처리 버퍼드리더 얻어옴

                StringBuilder sb = new StringBuilder();

                String line = null;

                while ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }

                is.close();

                result = sb.toString();
                //Log.e("httpClientResult", result);
                if(result.equals("fail")){
                    return false;
                } else {
                    return true;
                }
            } catch (Exception e) {
                //Log.e("catch", e.getMessage());
                return false;
            }
        }

        protected void onPostExecute(Boolean result){
            Log.e("onPostExecute", result.toString());
        }

        //기기정보
        protected String[] getDeviceInfo() {
            //System.out.println("telManager");
            TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

            String[] info = new String[3];
            try{
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                }

                info[0] = telManager.getLine1Number();
                //System.out.println("telManager2");
                //System.out.println(telManager);
                //Log.e("telManager", telManager.getLine1Number());
                info[1] = Build.DEVICE;
                info[2] = Build.VERSION.RELEASE;
                return info;
            }catch(Exception e){
                info[0] = null;
                return info;
            }
        }
    }

    private class getMarketVersion extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(Void... params) {

            try {

                ArrayList<NameValuePair> pairs = new ArrayList<NameValuePair>();
                pairs.add(new BasicNameValuePair("type", "android"));

                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(PageInfo.MARKET_APP_VERSION);
                post.setEntity(new UrlEncodedFormEntity(pairs, "utf-8"));

                HttpResponse response = client.execute(post);

                HttpEntity ent = response.getEntity();

                //Log.e("Response Value", EntityUtils.toString(ent));
                InputStream is = null;
                String result = "";
                is = ent.getContent();

                BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);	// 인코딩 처리 버퍼드리더 얻어옴

                StringBuilder sb = new StringBuilder();

                String line = null;

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }

                is.close();

                result = sb.toString();
                //Log.e("httpClientResult", result);

                if(result.equals("fail")){
                    return null;
                } else {
                    return result;
                }
            } catch (Exception e) {
                //Log.e("catch", e.getMessage());
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {

            PackageInfo pi = null;
            try {
                pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            verSion = String.valueOf(pi.versionCode);
            marketVersion = result;

            System.out.println("verSion" + verSion);
            System.out.println("marketVersion"+marketVersion);

            //Log.e("verSion", verSion);
            //Log.e("marketVersion", marketVersion);

            if (marketVersion != null && Integer.parseInt(marketVersion) > Integer.parseInt(verSion)) {
                mDialog.setMessage("업데이트 후 사용해주세요.")
                        .setCancelable(false)
                        .setPositiveButton("업데이트 바로가기",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog,
                                                        int id) {
                                        Intent marketLaunch = new Intent(
                                                Intent.ACTION_VIEW);
                                        marketLaunch.setData(Uri
                                                .parse("https://play.google.com/store/apps/details?id="+getPackageName()));
                                        startActivity(marketLaunch);
                                        finish();
                                    }
                                });
                AlertDialog alert = mDialog.create();
                alert.setTitle("안 내");
                alert.show();
            }
            super.onPostExecute(result);
        }
    }


    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File imageFile = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        return imageFile;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == INPUT_FILE_REQUEST_CODE && resultCode == RESULT_OK) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (mFilePathCallback == null) {
                    super.onActivityResult(requestCode, resultCode, data);
                    return;
                }
                Uri[] results = new Uri[]{getResultUri(data)};

                mFilePathCallback.onReceiveValue(results);
                mFilePathCallback = null;
            } else {
                if (mUploadMessage == null) {
                    super.onActivityResult(requestCode, resultCode, data);
                    return;
                }
                Uri result = getResultUri(data);

                Log.d(getClass().getName(), "openFileChooser : "+result);
                mUploadMessage.onReceiveValue(result);
                mUploadMessage = null;
            }
        } else {
            if (mFilePathCallback != null) mFilePathCallback.onReceiveValue(null);
            if (mUploadMessage != null) mUploadMessage.onReceiveValue(null);
            mFilePathCallback = null;
            mUploadMessage = null;
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private Uri getResultUri(Intent data) {
        Uri result = null;
        if(data == null || TextUtils.isEmpty(data.getDataString())) {
            // If there is not data, then we may have taken a photo
            if(mCameraPhotoPath != null) {
                result = Uri.parse(mCameraPhotoPath);
            }
        } else {
            String filePath = "";
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                filePath = data.getDataString();
            } else {
                filePath = "file:" + RealPathUtil.getRealPath(this, data.getData());
            }
            result = Uri.parse(filePath);
        }

        return result;
    }
}
