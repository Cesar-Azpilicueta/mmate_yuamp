package com.flash21.yuamp_android;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class AgreeActivity extends AppCompatActivity {

//    private EditText authText;
    private Button confirm_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agree);

//        authText = findViewById(R.id.authText);
        confirm_button = findViewById(R.id.confirm_button);

//        authText.setFocusable(false);

        confirm_button.setOnClickListener(new View.OnClickListener(){

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                SharedPreferences pref= getSharedPreferences("pref", MODE_PRIVATE); // 선언
                SharedPreferences.Editor editor = pref.edit();// editor에 put 하기
                editor.putString("AuthValue","yes"); //First라는 key값으로 id 데이터를 저장한다.
                editor.commit(); //완료한다.
                Intent intent = new Intent(AgreeActivity.this, SplashActivity.class);
                startActivity(intent);
                finish();
            }
        });

        txtRead();
    }

    private void txtRead(){
        String data = null;
        InputStream inputStream = getResources().openRawResource(R.raw.permissiontxt);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        int i;
        try {
            i = inputStream.read();
            while (i != -1) {
                byteArrayOutputStream.write(i);
                i = inputStream.read();
            }

            data = new String(byteArrayOutputStream.toByteArray(),"UTF-8");
            //Toast.makeText(getBaseContext(), data, Toast.LENGTH_LONG).show();
//            authText.setText(data);
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
