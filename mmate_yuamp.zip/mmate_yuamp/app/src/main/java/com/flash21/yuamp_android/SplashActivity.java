package com.flash21.yuamp_android;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.webkit.CookieManager;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@SuppressLint("HandlerLeak")
public class SplashActivity extends Activity {

    private String tk = "";

    private String INDEX_PAGE = null;

    private String connName = "";

    private boolean pushChk = false;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);

        SharedPreferences sharedPreferences= getSharedPreferences("pref", MODE_PRIVATE);    // test 이름의 기본모드 설정, 만약 test key값이 있다면 해당 값을 불러옴.
        String AuthValue = sharedPreferences.getString("AuthValue","");

        Log.i("Splash", "AuthValue : " + AuthValue);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            //11 이상
            if (AuthValue.equals("yes")) {
                //push알림 받았을경우
                if (getIntent().getExtras() != null && this.getIntent().getExtras().containsKey("board_id")) {
                    Bundle b = getIntent().getExtras();
                    String board_id = b.getString("board_id");
                    String board_no = b.getString("board_no");

                    Log.e("board_id :: ", board_id);
                    Log.e("board_no :: ", board_no);

                    if (board_id.equals("notice")) {
                        INDEX_PAGE = PageInfo.BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    } else if (board_id.equals("hongbo")) {
                        INDEX_PAGE = PageInfo.HONGBO_BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    } else if (board_id.equals("event")) {
                        INDEX_PAGE = PageInfo.EVENT_BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    }
                    pushChk = true;
                } else {
                    pushChk = false;
                }

                if (INDEX_PAGE == null) {
                    INDEX_PAGE = PageInfo.INDEX_PAGE;
                }

                //권한체크시작
                TedPermission.with(this)
                        .setPermissionListener(permissionlistener)
                        .setRationaleMessage("기기 접근 권한이 필요합니다.")
                        .setDeniedMessage("기기 접근권한을 허용하지 않아 종료됩니다.\n[설정] > " + getResources().getString(R.string.app_name) + " > [권한] 에서 권한을 허용할 수 있습니다.")
                        .setPermissions(
                                Manifest.permission.INTERNET,
                            /*Manifest.permission.CALL_PHONE,
                            Manifest.permission.SEND_SMS,*/
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_PHONE_NUMBERS
                        )
                        .check();
            } else {
                Intent intent = new Intent(SplashActivity.this, AuthActivity.class);
                startActivity(intent);
                finish();
            }
        }else{
            //10이하
            if (AuthValue.equals("yes")) {
                //push알림 받았을경우
                if (getIntent().getExtras() != null && this.getIntent().getExtras().containsKey("board_id")) {
                    Bundle b = getIntent().getExtras();
                    String board_id = b.getString("board_id");
                    String board_no = b.getString("board_no");

                    Log.e("board_id :: ", board_id);
                    Log.e("board_no :: ", board_no);

                    if (board_id.equals("notice")) {
                        INDEX_PAGE = PageInfo.BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    } else if (board_id.equals("hongbo")) {
                        INDEX_PAGE = PageInfo.HONGBO_BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    } else if (board_id.equals("event")) {
                        INDEX_PAGE = PageInfo.EVENT_BOARD_VIEW_PAGE + "?brd_no=" + board_no;
                    }
                    pushChk = true;
                } else {
                    pushChk = false;
                }

                if (INDEX_PAGE == null) {
                    INDEX_PAGE = PageInfo.INDEX_PAGE;
                }

                //권한체크시작
                TedPermission.with(this)
                        .setPermissionListener(permissionlistener)
                        .setRationaleMessage("기기 접근 권한이 필요합니다.")
                        .setDeniedMessage("기기 접근권한을 허용하지 않아 종료됩니다.\n[설정] > " + getResources().getString(R.string.app_name) + " > [권한] 에서 권한을 허용할 수 있습니다.")
                        .setPermissions(
                                Manifest.permission.INTERNET,
                            /*Manifest.permission.CALL_PHONE,
                            Manifest.permission.SEND_SMS,*/
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.READ_PHONE_STATE
                        )
                        .check();
            } else {
                Intent intent = new Intent(SplashActivity.this, AuthActivity.class);
                startActivity(intent);
                finish();
            }
        }

	}

	//리스너 넣고
    PermissionListener permissionlistener = new PermissionListener() {

        //권한허가 모두 다 되었을경우
        @Override
        public void onPermissionGranted() {
            //Toast.makeText(SplashActivity.this, "권한 허가", Toast.LENGTH_SHORT).show();

            tk = FirebaseInstanceId.getInstance().getToken(); //토큰값 받기
            //Log.e("token", tk);

            InsertToken it = new InsertToken();
            it.execute(new String[]{PageInfo.INSERT_PUSH_DATA_PAGE});

        }

        //권한허가 하나라도 안했을경우
        @Override
        public void onPermissionDenied(ArrayList<String> deniedPermissions) {
            Toast.makeText(SplashActivity.this, deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            finish();
        }
    };

    // TOKEN 입력 //
    @SuppressWarnings("deprecation")
    private class InsertToken extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... urls) {
            String url = urls[0];

            PackageInfo info = null;

            try {
                info = getPackageManager().getPackageInfo(getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

            try {
                System.out.println("!!!!!!!!!trye1" + url);
                ArrayList<NameValuePair> pairs = new ArrayList<NameValuePair>();
                pairs.add(new BasicNameValuePair("key_num", tk));
                pairs.add(new BasicNameValuePair("j_cellNo", getDeviceInfo()[0]));
                /*pairs.add(new BasicNameValuePair("j_cellNo", "01043305737"));*/
                pairs.add(new BasicNameValuePair("device", getDeviceInfo()[1]));
                pairs.add(new BasicNameValuePair("version", getDeviceInfo()[2]));
                pairs.add(new BasicNameValuePair("j_siteKey", "ST0043"));
                pairs.add(new BasicNameValuePair("type", "android"));
                pairs.add(new BasicNameValuePair("j_division", "MOBILE"));
                pairs.add(new BasicNameValuePair("app_version", info.versionCode + ""));
                HttpClient client = new DefaultHttpClient();
                HttpPost post = new HttpPost(url);
                post.setEntity(new UrlEncodedFormEntity(pairs, "utf-8"));

                HttpResponse response = client.execute(post);

                System.out.println("!!!!!!!!!" + post);
                HttpEntity ent = response.getEntity();
                //Log.e("Response Value", EntityUtils.toString(ent));
                InputStream is = null;
                String result = "";
                is = ent.getContent();

                //  쿠키를 동기화 시킨다.
                List<Cookie> cookies = ((DefaultHttpClient)client).getCookieStore().getCookies();

                //Log.e("cookies.size()", cookies.size() + "");
                if (!cookies.isEmpty()) {
                    for (int i = 0; i < cookies.size(); i++) {

                        String cookieString = cookies.get(i).getName() + "=" + cookies.get(i).getValue();
                        //Log.e("cookieString", cookieString);

                        if(MainActivity.cookieManager == null){
                            MainActivity.cookieManager = CookieManager.getInstance();
                        }
                        MainActivity.cookieManager.setCookie(PageInfo.INDEX_PAGE, cookieString);
                    }
                }

                BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8);	// 인코딩 처리 버퍼드리더 얻어옴

                StringBuilder sb = new StringBuilder();

                String line = null;

                while ((line = reader.readLine()) != null) {
                    //sb.append(line).append("\n");
                    sb.append(line);
                }

                is.close();

                result = sb.toString();
                //Log.e("httpClientResult", result);
                if(result.equals("fail")){
                    return false;
                } else {
                    connName = result;

                    return true;
                }
            } catch (Exception e) {
                //Log.e("catch", e.getMessage());
                return false;
            }
        }

        protected void onPostExecute(Boolean result){

            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            System.out.println("11111111111111" + pushChk);
            System.out.println("22222222222222" + result);
            if(pushChk){
//                Toast.makeText(getBaseContext(), "안녕하세요. " + connName + "님", Toast.LENGTH_LONG).show();
                intent.putExtra("moveUrl", PageInfo.INDEX_PAGE2);
            }else{
                if(result == true) {

                    //Log.e("main", "Success");
                    /*Toast.makeText(getBaseContext(), "안녕하세요. " + connName + "님", Toast.LENGTH_LONG).show();*/
                    intent.putExtra("moveUrl", PageInfo.INDEX_PAGE2);
                }else{
                    //Log.e("main", "Fail");
                    Toast.makeText(getBaseContext(), "죄송합니다. 허가된 인원이 아닙니다.", Toast.LENGTH_LONG).show();
                    intent.putExtra("moveUrl", PageInfo.FAIL_PAGE);
                }
            }

            //MainActivity 이동
            startActivity(intent);
            //SplashActivity 종료 (종료하지 않으면 기기 back버튼 클릭시 Splash 화면으로 돌아온다.
            finish();
        }

        //기기정보
        protected String[] getDeviceInfo() {
            TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            String[] info = new String[3];
            if (ActivityCompat.checkSelfPermission(SplashActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(SplashActivity.this, Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(SplashActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            }
            info[0] = telManager.getLine1Number();
            info[1] = Build.DEVICE;
            info[2] = Build.VERSION.RELEASE;
            return info;
        }
    }
}

