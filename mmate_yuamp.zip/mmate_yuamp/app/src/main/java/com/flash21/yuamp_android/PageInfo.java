package com.flash21.yuamp_android;

public class PageInfo {

	// 기본경로 페이지
	public static final String INDEX_PAGE = "https://ynceo-mmate.flash21.com/";

	// 성공 후 YUAMP 이동
	public static final String INDEX_PAGE2 = "http://192.168.0.16/s/YUAMP/main.do";

	public static final String MAIN_PAGE = "http://192.168.0.16/s/YUAMP/main.do";

	//마켓 앱버전 ( DATABASE 로 관리 )
	public static final String MARKET_APP_VERSION = "http://192.168.0.16/s/ST0043/appversion.do?searchSITE_KEY=ST0043";

	// 멤버 확인 후 구글키와 핸드폰 번호를 저장하는 페이지
	public static final String INSERT_PUSH_DATA_PAGE = INDEX_PAGE + "servlet/j_spring_security_check";

	// 실패페이지
	public static final String FAIL_PAGE = INDEX_PAGE + "fail";


	// 공지사항게시판 상세 페이지
	public static final String BOARD_VIEW_PAGE = INDEX_PAGE + "board_list";
	// 홍보게시판 상세 페이지
	public static final String HONGBO_BOARD_VIEW_PAGE = INDEX_PAGE + "hongbo_board_list";
	// 행사 참석
	public static final String EVENT_BOARD_VIEW_PAGE = INDEX_PAGE + "event_board_list";

}
